<?php
session_start();
require_once '../config.php';

// Check if user is admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../login.php");
    exit();
}

// Handle status update
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$new_status, $order_id]);
    
    header("Location: orders.php");
    exit();
}

// Fetch all orders with user information
$stmt = $conn->query("
    SELECT 
        orders.*,
        users.email as user_email
    FROM orders
    LEFT JOIN users ON orders.user_id = users.id
    ORDER BY orders.created_at DESC
");
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Siparişler - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .order-details {
            display: none;
        }
        .order-details.show {
            display: table-row;
        }
        .status-Beklemede { color: #ffc107; }
        .status-Onaylandı { color: #0d6efd; }
        .status-Kargoda { color: #6f42c1; }
        .status-Tamamlandı { color: #198754; }
        .status-İptalEdildi { color: #dc3545; }
    </style>
</head>
<body>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3>Siparişler</h3>
                        <a href="dashboard.php" class="btn btn-primary">Ürün Yönetimine Dön</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Sipariş No</th>
                                        <th>Müşteri</th>
                                        <th>Telefon</th>
                                        <th>Toplam Tutar</th>
                                        <th>Durum</th>
                                        <th>Tarih</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($orders as $order): ?>
                                    <tr>
                                        <td>#<?php echo $order['id']; ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($order['full_name']); ?><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($order['user_email']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($order['phone']); ?></td>
                                        <td><?php echo number_format($order['total_amount'], 2); ?> TL</td>
                                        <td>
                                            <span class="status-<?php echo $order['status']; ?>">
                                                <?php echo $order['status']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-info view-details" data-order-id="<?php echo $order['id']; ?>">
                                                Detaylar
                                            </button>
                                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#statusModal<?php echo $order['id']; ?>">
                                                Durum Güncelle
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="order-details" id="details<?php echo $order['id']; ?>">
                                        <td colspan="7">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h5>Sipariş Detayları</h5>
                                                    <p><strong>Teslimat Adresi:</strong><br><?php echo nl2br(htmlspecialchars($order['address'])); ?></p>
                                                    
                                                    <?php
                                                    $stmt = $conn->prepare("
                                                        SELECT * FROM order_items 
                                                        WHERE order_id = ?
                                                    ");
                                                    $stmt->execute([$order['id']]);
                                                    $items = $stmt->fetchAll();
                                                    ?>
                                                    
                                                    <table class="table table-sm">
                                                        <thead>
                                                            <tr>
                                                                <th>Ürün</th>
                                                                <th>Adet</th>
                                                                <th>Birim Fiyat</th>
                                                                <th>Toplam</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach($items as $item): ?>
                                                            <tr>
                                                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                                                <td><?php echo $item['quantity']; ?></td>
                                                                <td><?php echo number_format($item['price'], 2); ?> TL</td>
                                                                <td><?php echo number_format($item['quantity'] * $item['price'], 2); ?> TL</td>
                                                            </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Status Update Modal -->
                                    <div class="modal fade" id="statusModal<?php echo $order['id']; ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Sipariş Durumu Güncelle</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form method="POST">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label">Yeni Durum</label>
                                                            <select name="status" class="form-select" required>
                                                                <option value="Beklemede" <?php echo $order['status'] == 'Beklemede' ? 'selected' : ''; ?>>Beklemede</option>
                                                                <option value="Onaylandı" <?php echo $order['status'] == 'Onaylandı' ? 'selected' : ''; ?>>Onaylandı</option>
                                                                <option value="Kargoda" <?php echo $order['status'] == 'Kargoda' ? 'selected' : ''; ?>>Kargoda</option>
                                                                <option value="Tamamlandı" <?php echo $order['status'] == 'Tamamlandı' ? 'selected' : ''; ?>>Tamamlandı</option>
                                                                <option value="İptal Edildi" <?php echo $order['status'] == 'İptal Edildi' ? 'selected' : ''; ?>>İptal Edildi</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                                                        <button type="submit" name="update_status" class="btn btn-primary">Güncelle</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle order details
        document.querySelectorAll('.view-details').forEach(button => {
            button.addEventListener('click', () => {
                const orderId = button.dataset.orderId;
                const details = document.getElementById('details' + orderId);
                details.classList.toggle('show');
            });
        });
    </script>
</body>
</html> 